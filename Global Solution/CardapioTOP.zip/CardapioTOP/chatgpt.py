import requests
import json

# Função para solicitar os dados ao usuário
def solicitar_dados():
    quantidade_pessoas = int(input("Quantidade de pessoas a serem alimentadas: "))
    quantidade_refeicoes = int(input("Quantidade de refeições a serem produzidas: "))

    ingredientes = {}
    while True:
        ingrediente = input("Nome do ingrediente (ou 'sair' para finalizar): ")
        if ingrediente.lower() == "sair":
            break
        quantidade = float(input("Quantidade disponível do ingrediente: "))
        validade = input("Prazo de validade ou grau de maturação do ingrediente: ")
        ingredientes[ingrediente] = {"quantidade": quantidade, "validade": validade}

    return quantidade_pessoas, quantidade_refeicoes, ingredientes

# Função para enviar a solicitação ao Chat GPT e obter o planejamento do cardápio
def obter_plano_cardapio(quantidade_pessoas, quantidade_refeicoes, ingredientes):
    url = url = "https://api.openai.com/v1/engines/davinci/completions"
    prompt = f"Quantidade de pessoas: {quantidade_pessoas}\nQuantidade de refeições: {quantidade_refeicoes}\nIngredientes disponíveis:\n"
    for ingrediente, detalhes in ingredientes.items():
        quantidade = detalhes["quantidade"]
        validade = detalhes["validade"]
        prompt += f"- {ingrediente}: {quantidade}, validade: {validade}\n"

    payload = {
        "prompt": prompt,
        "temperature": 0.6,
        "max_tokens": 100,
        "top_p": 1.0,
        "frequency_penalty": 0.0,
        "presence_penalty": 0.0
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"  # Substitua YOUR_API_KEY pela sua chave de API do OpenAI
    }

    response = requests.post(url, headers=headers, data=json.dumps(payload))
    response_json = response.json()
    print(response_json)
    completions = response_json["choices"][0]["text"]["content"] if "choices" in response_json else ""
    completions = completions.strip().split("\n") if completions else []

    return completions

# Função para exibir o planejamento do cardápio
def exibir_cardapio(cardapio):
    print("Planejamento do Cardápio:")
    print("-------------------------")
    for dia, refeicao in enumerate(cardapio, start=1):
        print(f"Dia {dia}: {refeicao}")
    print("-------------------------")

# Função principal
def main():
    quantidade_pessoas, quantidade_refeicoes, ingredientes = solicitar_dados()
    cardapio = obter_plano_cardapio(quantidade_pessoas, quantidade_refeicoes, ingredientes)
    exibir_cardapio(cardapio)

# Execução do programa principal
main()