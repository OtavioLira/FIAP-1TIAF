import requests
import json

#Função para solicitar os dados para o usuario
def solicitar_dados():
    qtd_pessoas = int(input("Digite a quantidade de pessoas: "))
    qtd_refeicoes = int(input("Digite a quantidade de refeições que serão produzidas: "))

    ingredientes = {} 
    while True:
        ingrediente = input("Nome do ingrediente (ou 'sair' para finalizar): ")
        if ingrediente.lower() == "sair":
            break
        quantidade = float(input("Quantidade disponível do ingrediente: "))
        print("""\n   Tabela de Maturação
        Fruta Verde: 9 - 13
        Madura: 14-16
        Fruta Passada: 17-21""")
        validade = input("Digite o Grau de maturação do ingrediente: ")
        ingredientes[ingrediente] = {"quantidade": quantidade, "validade": validade}

    return qtd_pessoas, qtd_refeicoes, ingredientes
solicitar_dados()